About TotalHLT
TotalHLT (Total Highlight) is a Lister plugin for TotalCommander. The major function is to display source code files with syntax highlight. This is a very preliminary version. It's based on the hlight v1.1 which is available on totalcmd.net at the following link:
http://www.totalcmd.net/plugring/hlight.html

Both hlight and TotalHLT are built on the excellent library Highlight (http://www.andre-simon.de/). 
This version (v1.7.0.160) features:
     1). It supports "Space" and "Shift+Space" for pagedown and pageup.
     2). It supports themes.
     3). Pressing "L" key can change the line spacing to double line spaced. 
         Pressing "Shift + L" can change the line spacing to single line.
     4). Pressing "T" key can increase the font size by two points. 
         Pressing "Shift + T" can decrease the font size by two points.
     5). Supports TotalCommander 8 win32/x64.
     6). Supports setting width for line numbers and whether to print the leading zeros of 
         line numbers.
     7). Supports font size set in the theme file.



Installation:
Double-click TotalHLT_wlx_v1_5b130.zip then it can be automatically installed 
(assumed that you are using the latest version of TotalCommander).

Requirements:
No special requirement, provided that you are using a relatively new computer
and Windows OS.

Usuage:
In TC, when the selection bar is on a source code file, press "F3" or Ctrl+q",
you will see the content of the file with nice colors.


License:
Copyright (C) 2004-2013 W. Dong, taohe@hotmail.com
License to copy, use, and redistribute this software for any purpose is granted 
provided that this notice may not be removed from this document. 

This software is provided 'as-is', without any express or implied warranty. 
In no event will the authors be held liable for any damages arising from the 
use of this software. 
