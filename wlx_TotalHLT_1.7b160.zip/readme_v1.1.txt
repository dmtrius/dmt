About
-----
highlight.wlx 1.1
Copyright (C) 2004 Jens Thee� <jens@theess.com>

The sources to this plugin are available at:
http://www.theess.com/highlight

Highlight.wlx is a Total Commander Lister-plugin for viewing source files with
syntax highlighting. Supports more than 100 programming languages. Color theme 
is customizable.

Uses the sources from the excellent "highlight" project by Andre Simon:
http://www.andre-simon.de


Minimum requirements
--------------------
- Total Commander 5.51


Installation
------------
- Unzip the contents of the archive to the addon directory of Total Commander.
- In Total Commander, select "Configuration->Options" from the menu.
- Navigate to the "Edit/View" tab and select "Configure internal viewer".
- In the "Configure Lister" dialog click on "LS-Plugins" and then "Add" and 
  select the "highlight.wlx".
- Click on "Ok" a few times until all the dialogs have disappeared.


Customizing
-----------
Highlight will display all files for which there is a language definition file 
in the langdefs directory. If there is more than one file extension for a 
language, the extensions must be listed in extensions.conf.

You can change the following options in highlight.ini:
- theme=<file.style>: Specify a theme from .\themes for coloring the file.
- linenumbers=<true|false>: Display linenumbers.
- tabspaces=<number>: Size of tabs.
- indent=<file.indent>: Beautify code using a scheme from .\indentSchemes.

License
-------

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    
Changelog
---------
* 1.1
- Added highlight.ini for configuration options.
- Able to display files >32KB.
- New pas.lang for Pascal syntax.
- Added dpr,inc,bpg,dpk to the pascal extensions.
- Default theme is now nedit.style.
* 1.0
- First release.